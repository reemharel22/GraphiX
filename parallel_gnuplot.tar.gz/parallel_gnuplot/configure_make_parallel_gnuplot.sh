#! /bin/bash
make distclean
./configure CFLAGS="-fopenmp" CXXFLAGS="-fopenmp" --prefix=../gnuplot_exec/
make install; make all;
