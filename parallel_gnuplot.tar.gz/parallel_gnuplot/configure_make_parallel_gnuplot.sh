#! /bin/bash
make distclean
echo $PWD
./configure CFLAGS="-fopenmp" CXXFLAGS="-fopenmp" --prefix=$PWD/../gnuplot_exec/
make install; make all;
